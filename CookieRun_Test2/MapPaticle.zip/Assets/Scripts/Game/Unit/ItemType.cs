using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum UnitType
{
    None,
    Player,
    Food,
    Coin,
}